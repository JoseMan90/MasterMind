﻿using System;
using System.Linq;
using System.Speech.Recognition;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Threading;
using System.Windows.Input;
using System.Windows.Media;
using System.Globalization;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Speech.Synthesis;
using WiiGestureLib;
using WiimoteLib;
using System.IO;

namespace MasterMind
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Wiimote objects
        Wiimote wm;
        GestureCapturer gc;
        WiiGestureLib.GestureRecognizer gr;
        SpeechRecognitionEngine speechRecognizer = new SpeechRecognitionEngine(new CultureInfo("en-US"));
        InkAnalyzer m_analyzer;
        string _solution;
        string _numberToTest;
        TextBlock[] _digitsTB;
        InkCanvas[] _canvasTB;
        Border[] _borders;
        int _numTries;
        int cont = 0;
        int puntuacion = 100;
        Random r = new Random();
        Key[] _validKeys = new Key[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6, Key.D7, Key.D8, Key.D9,
                                       Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4, Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9, };
        int _cursorIndex;
        int CursorIndex
        {
            get { return _cursorIndex; }
            set
            {
                foreach (var border in _borders)
                {
                    border.BorderThickness = new Thickness(1);
                    border.BorderBrush = Brushes.Black;
                    border.IsEnabled = false;
                }
                _cursorIndex = value;
                if (_cursorIndex >= 0)
                {
                    _borders[_cursorIndex].BorderThickness = new Thickness(3);
                    _borders[_cursorIndex].BorderBrush = SystemColors.HighlightBrush;
                    _borders[_cursorIndex].IsEnabled = true;
                }
            }
        }

        private static Dictionary<string, long> numberTable =
    new Dictionary<string, long>
        {{"zero",0},{"one",1},{"two",2},{"three",3},{"four",4},
        {"five",5},{"six",6},{"seven",7},{"eight",8},{"nine",9},
        {"ten",10},{"eleven",11},{"twelve",12},{"thirteen",13},
        {"fourteen",14},{"fifteen",15},{"sixteen",16},
        {"seventeen",17},{"eighteen",18},{"nineteen",19},{"twenty",20},
        {"thirty",30},{"forty",40},{"fifty",50},{"sixty",60},
        {"seventy",70},{"eighty",80},{"ninety",90},{"hundred",100},
        {"thousand",1000},};

        public static long ToLong(string numberString)
        {
            var numbers = Regex.Matches(numberString, @"\w+").Cast<Match>()
                 .Select(m => m.Value.ToLowerInvariant())
                 .Where(v => numberTable.ContainsKey(v))
                 .Select(v => numberTable[v]);
            long acc = 0, total = 0L;
            foreach (var n in numbers)
            {
                if (n >= 1000)
                {
                    total += (acc * n);
                    acc = 0;
                }
                else if (n >= 100)
                {
                    acc *= n;
                }
                else acc += n;
            }
            return (total + acc);
        }

        public MainWindow()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(MainWindow_Loaded);
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            wm = new Wiimote();
            gc = new GestureCapturer();
            gr = new WiiGestureLib.GestureRecognizer();

            WiiGestureLib.GestureRecognizer newGestureRecog = ReadFromBinaryFile<WiiGestureLib.GestureRecognizer>("ProtoGestos");
            gr = newGestureRecog;

            wm.WiimoteChanged += Wm_WiimoteChanged;
            gc.GestureCaptured += Gc_GestureCaptured;
            gr.GestureRecognized += Gr_GestureRecognized;

            wm.Connect();
            wm.SetLEDs(3);
            wm.SetReportType(InputReport.ButtonsAccel, true);

            m_analyzer = new InkAnalyzer();

            m_analyzer.AnalysisModes = AnalysisModes.AutomaticReconciliationEnabled;
            m_analyzer.ResultsUpdated += M_analyzer_ResultsUpdated;
            c1.StrokeCollected += C1_StrokeCollected;
            c2.StrokeCollected += C2_StrokeCollected;
            c3.StrokeCollected += C3_StrokeCollected;
            c4.StrokeCollected += C4_StrokeCollected;
            c1.StrokeErasing += C1_StrokeErasing;
            c2.StrokeErasing += C2_StrokeErasing;
            c3.StrokeErasing += C3_StrokeErasing;
            c4.StrokeErasing += C4_StrokeErasing;

            Grammar gb = new Grammar("XMLVoice.srgs");

            speechRecognizer.LoadGrammar(gb);

            speechRecognizer.SpeechRecognized += SpeechRecognizer_SpeechRecognized;
            speechRecognizer.SpeechRecognitionRejected += SpeechRecognizer_SpeechRecognitionRejected;
            speechRecognizer.SpeechDetected += SpeechRecognizer_SpeechDetected;
            speechRecognizer.SetInputToDefaultAudioDevice();

            speechRecognizer.RecognizeAsync(RecognizeMode.Multiple);
            //  speechRecognizer.RecognizeAsyncCancel();


            _digitsTB = new TextBlock[] { n1TB, n2TB, n3TB, n4TB };
            _canvasTB = new InkCanvas[] { c1, c2, c3, c4 };
            _borders = new Border[] { n1Border, n2Border, n3Border, n4Border };
            KeyDown += new KeyEventHandler(MainWindow_KeyDown);
            solutionTB.Visibility = Visibility.Hidden;   //Descomentar esta línea para ocultar la solución
            sol.Visibility = Visibility.Hidden;
            Dispatcher.BeginInvoke(new Action<string>(EscribeScore), string.Format("Score: {0}", puntuacion));
            NewGame();
        }

        #region WiiMote Implementation
        void EscribeLabel(string txt)
        {
            Score.Content = txt;
        }

        void EscribeScore(string txt)
        {
          
            wii.Content = txt;
        }

        private void Wm_WiimoteChanged(object sender, WiimoteChangedEventArgs e)
        {
            gc.OnWiimoteChanged(e.WiimoteState);
        }

        private void Gc_GestureCaptured(Gesture gesture)
        {
            gc.GestureCaptured -= Gc_GestureCaptured;
            gc.GestureCaptured += gr.OnGestureCaptured;
        }

        private void Gr_GestureRecognized(string gestureName)
        {
            Dispatcher.BeginInvoke(new Action<string>(EscribeLabel), string.Format("WiiMote: {0}", gestureName));
            cont++;
            Dispatcher.BeginInvoke(new Action<string>(EscribeNumber), gestureName);

        }

        void EscribeNumber(string digit)
        {

            if (digit == "1" | digit == "2" | digit == "3" | digit == "4"
                        | digit == "5" | digit == "6" | digit == "7" | digit == "8"
                        | digit == "9" | digit == "0")
            {
                if (_numberToTest.Contains(digit)) return;
                _digitsTB[_numberToTest.Length].Text = digit;

                _numberToTest += digit;
                CursorIndex = (CursorIndex + 1) % _borders.Length;
                if (_numberToTest.Length == _solution.Length)
                {
                    foreach (var digitTB in _digitsTB) digitTB.Text = "";
                    TestNumber(_numberToTest);
                    _numberToTest = "";
                }
            }
            else
            {
                return;
            }
        }


        #endregion

        #region Speech
        private void SpeechRecognizer_SpeechDetected(object sender, SpeechDetectedEventArgs e)
        {
            historyTB.Text += string.Format(" Voz reconocida \n");
        }

        private void SpeechRecognizer_SpeechRecognitionRejected(object sender, SpeechRecognitionRejectedEventArgs e)
        {
            historyTB.Text += string.Format(" No    le     he   oido  bien.Repita  por  favor  \n");
        }

        private void speech(string args) // defining the function which will accept a string parameter
        {
            SpeechSynthesizer synthesizer = new SpeechSynthesizer();
            synthesizer.SelectVoiceByHints(VoiceGender.Male, VoiceAge.Adult); // to change VoiceGender and VoiceAge check out those links below
            synthesizer.Volume = 100;  // (0 - 100)
            synthesizer.Rate = 0;     // (-10 - 10)
                                      // Synchronous
                                      //  synthesizer.Speak("Now I'm speaking, no other function'll work");
                                      // Asynchronous
            synthesizer.SpeakAsync("Results" + args); // here args = pran
            Thread.Sleep(3400);
            speechRecognizer.RecognizeAsync(RecognizeMode.Multiple);
        }

        private void SpeechRecognizer_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
          
            String temp = e.Result.Text;
            Dispatcher.BeginInvoke(new Action<string>(EscribeLabel), string.Format("Voice: {0}", temp));
            int size = temp.Count();
           
            var prueba = ToLong(temp);
            temp = prueba.ToString();
            var digit = "";
           
            for (var i = 0; i < temp.Count(); i++)
            {
                digit = temp.ElementAt(i).ToString();

                if (digit == "1" | digit == "2" | digit == "3" | digit == "4"
                        | digit == "5" | digit == "6" | digit == "7" | digit == "8"
                        | digit == "9" | digit == "0")
                {

                    if (_numberToTest.Contains(digit)) return;
                    _digitsTB[_numberToTest.Length].Text = digit.ToString();
                    _numberToTest += digit;
                    CursorIndex = (CursorIndex + 1) % _borders.Length;
                    if (_numberToTest.Length == _solution.Length)
                    {
                        foreach (var digitTB in _digitsTB) digitTB.Text = "";
                        TestNumber(_numberToTest);
                        _numberToTest = "";
                    }
                }
                else
                {
                    return;
                }
            }
        }
        #endregion

        #region Tinta
        private void C4_StrokeErasing(object sender, InkCanvasStrokeErasingEventArgs e)
        {
            m_analyzer.RemoveStroke(e.Stroke);
        }

        private void C3_StrokeErasing(object sender, InkCanvasStrokeErasingEventArgs e)
        {
            m_analyzer.RemoveStroke(e.Stroke);
        }

        private void C2_StrokeErasing(object sender, InkCanvasStrokeErasingEventArgs e)
        {
            m_analyzer.RemoveStroke(e.Stroke);
        }

        private void C1_StrokeErasing(object sender, InkCanvasStrokeErasingEventArgs e)
        {
            m_analyzer.RemoveStroke(e.Stroke);
        }

        private void C4_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
        {
            m_analyzer.AddStroke(e.Stroke);
            m_analyzer.BackgroundAnalyze();
        }

        private void C3_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
        {
            m_analyzer.AddStroke(e.Stroke);
            m_analyzer.BackgroundAnalyze();
        }

        private void C1_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
        {
            m_analyzer.AddStroke(e.Stroke);
            m_analyzer.BackgroundAnalyze();
        }

        private void C2_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
        {
            m_analyzer.AddStroke(e.Stroke);
            m_analyzer.BackgroundAnalyze();
        }

        private void M_analyzer_ResultsUpdated(object sender, ResultsUpdatedEventArgs e)
        {
            if (e.Status.Successful)
            {
                ContextNodeCollection nodes = ((InkAnalyzer)sender).FindLeafNodes();
                foreach (ContextNode node in nodes)
                {
                    if (node is InkWordNode)
                    {
                        InkWordNode t = node as InkWordNode;
                        var digit = t.GetRecognizedString();
                        Dispatcher.BeginInvoke(new Action<string>(EscribeLabel), string.Format("Ink: {0}", digit));
                        m_analyzer.RemoveStrokes(c1.Strokes);
                        m_analyzer.RemoveStrokes(c2.Strokes);
                        m_analyzer.RemoveStrokes(c3.Strokes);
                        m_analyzer.RemoveStrokes(c4.Strokes);
                        c1.Strokes.Clear(); c2.Strokes.Clear(); c3.Strokes.Clear(); c4.Strokes.Clear();
                       
                        if (digit == "1" | digit == "2" | digit == "3" | digit == "4"
                            | digit == "5" | digit == "6" | digit == "7" | digit == "8"
                            | digit == "9" | digit == "0")
                        {
                            if (_numberToTest.Contains(digit)) return;
                            _digitsTB[_numberToTest.Length].Text = digit;
                            _numberToTest += digit;
                            CursorIndex = (CursorIndex + 1) % _borders.Length;
                            if (_numberToTest.Length == _solution.Length)
                            {
                                foreach (var digitTB in _digitsTB) digitTB.Text = "";
                                TestNumber(_numberToTest);
                                _numberToTest = "";
                            }
                        }
                        else
                        {
                            return;
                        }
                    }

                }
            }
        }

        #endregion


        void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (!_validKeys.Contains(e.Key)) return;
            var digit = e.Key.ToString().Last().ToString();
            if (_numberToTest.Contains(digit)) return;
            _digitsTB[_numberToTest.Length].Text = digit;
            _numberToTest += digit;
            CursorIndex = (CursorIndex + 1) % _borders.Length;
            if (_numberToTest.Length == _solution.Length)
            {
                foreach (var digitTB in _digitsTB) digitTB.Text = "";
                TestNumber(_numberToTest);
                _numberToTest = "";
            }
        }

        void TestNumber(string number)
        {
            ++_numTries; puntuacion = puntuacion - 5;
            historyTB.Text += string.Format("{0}: {1} -> Deaths: {2} - Injuries: {3}.\n", _numTries, number, NumDeaths(_solution, number), NumInjuries(_solution, number));
            String s = string.Format(" {1}  {2} Deaths {3} Injuries \n", _numTries, number, NumDeaths(_solution, number), NumInjuries(_solution, number));
            Dispatcher.BeginInvoke(new Action<string>(EscribeScore), string.Format("Score: {0}", puntuacion));
            speechRecognizer.RecognizeAsyncCancel();
            speech(s);
          
            if (number == _solution)
            {
                solutionTB.Visibility = Visibility.Visible;   //Descomentar esta línea para ocultar la solución
                sol.Visibility = Visibility.Visible;
                historyTB.Text += string.Format("You have found it in {0} tries.\n", _numTries);
                historyTB.Text += string.Format("Press \"New Game\" to continue...\n", _numTries);
                historyTB.Text += string.Format("Your achivied Score\n", puntuacion);
                CursorIndex = -1;
            }
            historyTB.ScrollToEnd();
        }

        void NewGameButton_Click(object sender, RoutedEventArgs e)
        {
            NewGame();
        }

        void NewGame()
        {
            puntuacion = 100;
            _solution = GenerateValidNumber();
            solutionTB.Text = _solution;
            _numberToTest = "";
            _numTries = 0;
            historyTB.Text = "Welcome and good luck\n";
            historyTB.Text += "---------------------\n";
            foreach (var digitTB in _digitsTB) digitTB.Text = "";
            CursorIndex = 0;
        }

        int NumDeaths(string solution, string test)
        {
            return Enumerable.Range(0, solution.Length).Count(i => solution[i] == test[i]); //Esto es LINQ
        }

        int NumInjuries(string solution, string test)
        {
            return Enumerable.Range(0, solution.Length).Count(i => solution[i] != test[i] && solution.Contains(test[i])); //Esto es LINQ
        }

        string GenerateValidNumber() // cuatro números del 0 al 9, sin repetición
        {
            string n = "";
            while (n.Length < 4)
            {
                var d = r.Next(10).ToString();
                if (!n.Contains(d)) n += d;
            }
            return n;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (_numberToTest.Length > 0)
            {
                _digitsTB[_numberToTest.Length].Text = "";
                _numberToTest = _numberToTest.Remove(_numberToTest.Length - 1);
                CursorIndex = (CursorIndex - 1) % _borders.Length;
            }
            else
            {
                _digitsTB[_numberToTest.Length].Text = "";
                _numberToTest = "";
            }

        }

        public static T ReadFromBinaryFile<T>(string filePath)
        {
            using (Stream stream = File.Open(filePath, FileMode.Open))
            {
                var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                return (T)binaryFormatter.Deserialize(stream);
            }
        }


    }
}
